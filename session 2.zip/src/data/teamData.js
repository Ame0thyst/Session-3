const teamData = [
    {
      id: 1,
      name: 'Gilang Wiko Wicaksono',
      description: 'Universitas Muhammadiyah Riau',
      image: '/assets/gambar/1.jpg',
      socialLink: 'https://www.linkedin.com/in/gilangikoo/ ',
    },
    {
      id: 2,
      name: 'Dyah Ayu Wulandari',
      description: 'Universitas Brawijaya',
      image: '/assets/gambar/2.jpg',
      socialLink: 'http://linkedin.com/in/dyahayuw',
    },
    {
      id: 3,
      name: 'Rachel Valentina Selima',
      description: 'Universitas Katolik Soegijapranata Semarang',
      image: '/assets/gambar/3.jpg',
      socialLink: 'https://www.instagram.com/y0ur.valent_?igsh=MWN6cG1jMHhmazRibQ==',
    },
    {
        id: 4,
        name: 'Echa Andrea Gustiar ',
        description: 'Universitas Lampung',
        image: '/assets/gambar/4.jpg',
        socialLink: 'https://www.linkedin.com/in/echa-andrea-gustiar?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app ',
      },
      {
        id: 5,
        name: 'Zidane Putra Fadilah',
        description: 'universitas sriwijaya',
        image: '/assets/gambar/5.jpg',
        socialLink: 'http://www.linkedin.com/in/zidanepf',
      },
      {
        id: 6,
        name: 'Augrecelline',
        description: 'Binus University',
        image: '/assets/gambar/6.jpg',
        socialLink: 'http://linkedin.com/in/augrecelline-ab3945317',
      },
      {
        id: 7,
        name: 'Ilham Ramadhan ',
        description: 'STMIK Sinar Nusantara',
        image: '/assets/gambar/7.jpg',
        socialLink: 'https://www.linkedin.com/in/ilramadhan',
      },
      {
        id: 8,
        name: 'I Nengah Danarsa Suniadevta',
        description: 'Universitas Udayana',
        image: '/assets/gambar/8.jpg',
        socialLink: 'https://www.linkedin.com/in/i-nengah-danarsa-suniadevta',
      },
     
  ];
  
  export default teamData;